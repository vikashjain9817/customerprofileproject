package com.capgemini.capstore.CapstorePages.beans;


public class ProductFeedback {

	
	private int id;
	
	private Product product;

	private String productFeedback;
	
	private int rating;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getProductFeedback() {
		return productFeedback;
	}

	public void setProductFeedback(String productFeedback) {
		this.productFeedback = productFeedback;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

}
