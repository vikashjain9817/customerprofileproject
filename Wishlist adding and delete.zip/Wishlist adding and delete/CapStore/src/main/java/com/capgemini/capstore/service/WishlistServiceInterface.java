package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Wishlist;

public interface WishlistServiceInterface {


	public Wishlist displayProductsFromWishlist(int customerId);

	public Wishlist addProductsToWishlist(int customerId, int merchantId, Product product);

	List<Wishlist> deleteProductsFromWishlist(int customerId);

}
